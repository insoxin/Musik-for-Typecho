</a>
</body>



    &copy; <?php echo date('Y'); ?> <a href="<?php $this->options->siteUrl(); ?>"><?php $this->options->title(); ?>
Copyright &copy; <a href="http://blog.isoyu.com/">BLOG.ISOYU.COM</a><br><a href="#" target="_blank">豫ICP备15034003号-1</a> <span style="display:none;"><script language="javascript" type="text/javascript" src="http://js.users.51.la/18705002.js"></script></span>  <a href="http://blog.isoyu.com/sitemap/">Sitemap</a> 由<a target="_blank" href="http://typecho.org">Typecho</a> 强力驱动.<br><a target="_blank" href="http://mail.qq.com/cgi-bin/qm_share?t=qm_mailme&email=2_ri6e3t7ejs45uqqvW4tLY" style="text-decoration:none;"><img src="http://rescdn.qqmail.com/zh_CN/htmledition/images/function/qm_open/ico_mailme_12.png"/></a>
<script><script>
(function(){
    var bp = document.createElement('script');
    bp.src = '//push.zhanzhang.baidu.com/push.js';
    var s = document.getElementsByTagName("script")[0];
    s.parentNode.insertBefore(bp, s);
})();
</script>
<script>
function show(){
var date = new Date(); //日期对象
var now = "";
now = date.getFullYear()+"年"; //读英文就行了
now = now + (date.getMonth()+1)+"月"; //取月的时候取的是当前月-1如果想取当前月+1就可以了
now = now + date.getDate()+"日";
now = now + date.getHours()+"时";
now = now + date.getMinutes()+"分";
now = now + date.getSeconds()+"秒";
document.getElementById("nowDiv").innerHTML = now; //div的html是now这个字符串
setTimeout("show()",1000); //设置过1000毫秒就是1秒，调用show方法
}
</script>
<body onload="show()"> <!-- 网页加载时调用一次 以后就自动调用了-->
<div id="nowDiv"></div>
</body></span>
<script>
// 网页背景提示音，一般作为页面加载完毕后的提示，支持 IE9+/Firefox/chrome
// 直接使用 audio 标签貌似无法设置默认音量，所以使用 js 创建
var audio = new Audio("./msg.mp3"); //声音文件地址，支持mp3 或者 ogg
audio.volume = 0.2; //音量，取值范围 0.1 到 1.0
audio.play();
</script>